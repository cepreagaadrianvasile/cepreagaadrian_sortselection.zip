// 6) Insert sort 2(Cand cautam locul facem si tragerea)
#include<iostream>
using namespace std;
int  main()
{
    int n,i,j,k,a[50],b[50];
    cout<<"n=";cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>a[i];
    }
    b[0]=a[0];

    for(i=1;i<n;i++)
    {
        j=0;
        while(j<=i-1 && a[i]>b[j]) j++;
        for(k=i;k>=j+1;k--) b[k]=b[k-1];
        b[j]=a[i];
    }
    for(i=0;i<n;i++)
            cout<<b[i]<<" ";}