#include<iostream>
using namespace std;
int n;
int v[100];
int main(){
cout<<"n=";cin>>n;
for(int i=1;i<=n;i++){
    cout<<"v["<<i<<"]=";cin>>v[i];
}
int gata=0;
int copie=n;
while(gata==0){
    gata=1;
    for(int i=1;i<=n;i++){
        if(v[i+1]>v[i]){
            swap(v[i+1],v[i]);
            gata=0;
        }
        n--;
    }
}
n=copie;
for(int i=1;i<=n;i++){
    cout<<v[i]<<" ";}
}
