#include<iostream>
using namespace std;
int A[100],B[100],C[100];
int i,j,k,n,m;
int main(){
cout<<"n=";cin>>n;
cout<<"m=";cin>>m;
for(int i=1;i<=n;i++){
    cout<<"A["<<i<<"]=";cin>>A[i];
}
for(int i=1;i<=m;i++){
    cout<<"B["<<i<<"]=";cin>>B[i];
}
i=1;j=1;k=1;
while((i<=n)&&(j<=m)){
    if(A[i]<B[j]){
        C[k]=A[i];
        i++;
        k++;
    }
    else if(B[j]<A[i]){
        C[k]=B[j];
        j++;
        k++;
    }
    else{
        C[k]=A[i];
        C[k+1]=A[i];
        i++;
        j++;
        k=k+2;
    }
}
if((i<=n)&&(j>m)){
    for(j=i;j<=n;j++){
        C[k]=A[j];
        k++;
    }
}
if((i>n)&&(j<=m)){
    for(i=j;i<=m;i++){
        C[k]=B[i];
        k++;
    }
}
for(int i=1;i<=k;i++){
    cout<<C[i]<<" ";
}
return 0;
}