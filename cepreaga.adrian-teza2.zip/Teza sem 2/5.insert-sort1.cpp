#include<iostream>
using namespace std;
int main()
{
    int j,n,alesul,v[100];
    cout<<"n=";
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cout<<"v["<<i<<"]=";
        cin>>v[i];
    }
    for(int i=1;i<=n-1;i++)
    {
        alesul=v[i];
        j=i-1;
        while((alesul<v[j])&&(j>=0))
        {
            v[j+1]=v[j];
            j=j-1;
        }

        v[j+1]=alesul;
    }
    for(int i=1;i<=n;i++)
    {
        cout<<v[i]<<" ";
    }
    return 0;